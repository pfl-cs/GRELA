COPY votes FROM '/apsarapangu/disk1/lpf_files/workspace/CDEstor/data/STATS/workload/ins_heavy/init/votes.csv' CSV header;
COPY comments FROM '/apsarapangu/disk1/lpf_files/workspace/CDEstor/data/STATS/workload/ins_heavy/init/comments.csv' CSV header;
COPY badges FROM '/apsarapangu/disk1/lpf_files/workspace/CDEstor/data/STATS/workload/ins_heavy/init/badges.csv' CSV header;
COPY posts FROM '/apsarapangu/disk1/lpf_files/workspace/CDEstor/data/STATS/workload/ins_heavy/init/posts.csv' CSV header;
COPY tags FROM '/apsarapangu/disk1/lpf_files/workspace/CDEstor/data/STATS/workload/ins_heavy/init/tags.csv' CSV header;
COPY posthistory FROM '/apsarapangu/disk1/lpf_files/workspace/CDEstor/data/STATS/workload/ins_heavy/init/posthistory.csv' CSV header;
COPY users FROM '/apsarapangu/disk1/lpf_files/workspace/CDEstor/data/STATS/workload/ins_heavy/init/users.csv' CSV header;
COPY postlinks FROM '/apsarapangu/disk1/lpf_files/workspace/CDEstor/data/STATS/workload/ins_heavy/init/postlinks.csv' CSV header;
